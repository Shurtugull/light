import { useState } from "react";
import "./App.css";

const phrases = [
  "No",
  "Are you sure?",
  "Really sure ?",
  "Pookie please",
  "Don't do this to me",
  "You're breaking my heart ;(",
];
function App() {
  const [nocount, setNoCount] = useState(0);
  const [YesPressed, setYesPressed] = useState(false);
  const yesButtonSize = nocount * 20 + 16;

  function handleNoClick() {
    setNoCount(nocount + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(nocount, phrases.length - 1)];
  }

  return (
    <div className="valentine-container">
      {YesPressed ? (
        <>
          <img
            alt="bears kissing"
            src="https://gifdb.com/images/high/cute-love-bear-roses-ou7zho5oosxnpo6k.gif"
          />
          <div className="text">Yay!!!!</div>
        </>
      ) : (
        <>
          <img
            alt="bear with hearts"
            src="https://gifdb.com/images/high/cute-love-bear-roses-ou7zho5oosxnpo6k.gif"
          />

          <div>Will you be my valentine?</div>
          <div>
            <button
              className="yesButton"
              style={{ fontSize: yesButtonSize }}
              onClick={() => setYesPressed(true)}
            >
              Yes
            </button>
            <button onClick={handleNoClick} className="noButton">
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
